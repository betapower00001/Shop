export default function ForbiddenPage() {
  return (
    <div className="p-8 text-center">
      <h1 className="text-3xl font-bold mb-4">403 - Forbidden</h1>
      <p>คุณไม่มีสิทธิ์เข้าถึงหน้านี้</p>
    </div>
  );
}
