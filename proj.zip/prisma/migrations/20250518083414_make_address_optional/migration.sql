-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "address" TEXT;
