//src/app/checkout/page.tsx

'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useCartStore } from '@/store/cartStore'

export default function CheckoutPage() {
  const { items, totalPrice } = useCartStore()
  const router = useRouter()

  const userId = 1

  const [name, setName] = useState('')
  const [address, setAddress] = useState('')
  const [phone, setPhone] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('bank_transfer')
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    async function fetchUser() {
      try {
        const res = await fetch(`/api/user/${userId}`)
        if (!res.ok) throw new Error('ไม่สามารถดึงข้อมูลผู้ใช้ได้')
        const user = await res.json()
        setName(user.name || '')
        setAddress(user.address || '')
        setPhone(user.phone || '')
      } catch (error) {
        console.error(error)
      }
    }
    fetchUser()
  }, [userId])

  const handleCheckout = async () => {
    if (!name.trim() || !address.trim() || !phone.trim()) {
      alert('กรุณากรอกข้อมูลให้ครบ')
      return
    }
    if (items.length === 0) {
      alert('ไม่มีสินค้าในตะกร้า')
      return
    }

    setIsLoading(true)

    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          shippingName: name,
          shippingAddress: address,
          shippingPhone: phone,
          totalAmount: totalPrice,
          paymentMethod,
          orderItems: items.map(item => ({
            productId: item.id,
            quantity: item.quantity,
            totalAmount: item.price * item.quantity,
          })),
        }),
      })

      if (!res.ok) {
        const errText = await res.text()
        throw new Error(errText)
      }

      const { orderId } = await res.json()

      // เชื่อมโยงไปหน้าชำระเงินแต่ละแบบ
      if (paymentMethod === 'bank_transfer') {
        router.push(`/payments/upload-slip?orderId=${orderId}`)
      } else if (paymentMethod === 'credit_card') {
        router.push(`/payments/credit-card?orderId=${orderId}`)
      } else if (paymentMethod === 'cod') {
        alert('ยืนยันคำสั่งซื้อสำเร็จ! รอเจ้าหน้าที่ติดต่อกลับ')
        router.push('/order-success')
      }
    } catch (error: any) {
      alert('เกิดข้อผิดพลาด: ' + error.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto p-4">
      <h1 className="text-xl font-bold mb-4">สรุปคำสั่งซื้อ</h1>

      <ul>
        {items.length === 0 && <p>ไม่มีสินค้าในตะกร้า</p>}
        {items.map(item => (
          <li key={item.id} className="flex justify-between py-1">
            <span>{item.name} x {item.quantity}</span>
            <span>{(item.price * item.quantity).toFixed(2)} บาท</span>
          </li>
        ))}
      </ul>

      <div className="font-bold mb-4">ยอดรวม: {totalPrice.toFixed(2)} บาท</div>

      <div className="mb-4">
        <label>ชื่อผู้รับ:</label>
        <input
          type="text"
          value={name}
          onChange={e => setName(e.target.value)}
          className="w-full border px-2 py-1 mb-2"
          placeholder="ชื่อผู้รับ"
        />
        <label>ที่อยู่จัดส่ง:</label>
        <textarea
          value={address}
          onChange={e => setAddress(e.target.value)}
          className="w-full border px-2 py-1 mb-2"
          rows={3}
          placeholder="ที่อยู่จัดส่ง"
        />
        <label>เบอร์โทรศัพท์:</label>
        <input
          type="tel"
          value={phone}
          onChange={e => setPhone(e.target.value)}
          className="w-full border px-2 py-1"
          placeholder="เบอร์โทรศัพท์"
        />
      </div>

      <div className="mb-4">
        <label>วิธีการชำระเงิน:</label>
        <select
          value={paymentMethod}
          onChange={e => setPaymentMethod(e.target.value)}
          className="w-full border px-2 py-1"
        >
          <option value="bank_transfer">โอนเงิน</option>
          <option value="credit_card">บัตรเครดิต</option>
          <option value="cod">เก็บเงินปลายทาง</option>
        </select>
      </div>

      <button
        onClick={handleCheckout}
        disabled={isLoading || items.length === 0}
        className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {isLoading ? 'กำลังดำเนินการ...' : 'ยืนยันคำสั่งซื้อ'}
      </button>
    </div>
  )
}
