import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const url = new URL(req.url)
  const userIdStr = url.pathname.split('/').pop()
  const userId = Number(userIdStr)

  if (isNaN(userId)) {
    return NextResponse.json({ error: 'userId ไม่ถูกต้อง' }, { status: 400 })
  }

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      name: true,
      email: true,
      address: true,
      phone: true,
    },
  })

  if (!user) {
    return NextResponse.json({ error: 'ไม่พบผู้ใช้' }, { status: 404 })
  }

  return NextResponse.json(user)
}
